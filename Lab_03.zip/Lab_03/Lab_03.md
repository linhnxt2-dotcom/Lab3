# HTML PRACTICE LABS 

Lecture 03 — those belong to later sessions. This version only uses tags and concepts that Lecture 03 *("Create the HTML")* actually covers:
> - HTML document structure (`<!DOCTYPE>`, `lang`, `meta charset`, `meta viewport`)
> - Headings & paragraphs
> - All 3 hyperlink types (external, local/anchor, relative)
> - Images with `alt` and `loading="lazy"`
> - Audio & video embedding
> - Lists: ordered, unordered, definition, and **nested** lists
> - Semantic HTML5 tags (`header`, `nav`, `main`, `section`, `article`, `aside`, `footer`)
> - Tag / Attribute / Element concept, `data-*` attributes
> - Block / Inline / Inline-block concept
> - Basic External CSS (linking a stylesheet, simple colors/fonts — no advanced layout, no Flexbox/Grid, no `float`/`position` since those come later)
> - Emmet shortcuts, W3C Markup Validator

Reference screenshots of the expected result for each lab are provided as separate image files alongside this document (see the note at the top of each lab).

**Common requirements for all 3 labs (do not repeat per lab, apply everywhere):**
- Valid HTML5 (`<!DOCTYPE html>`, `lang` attribute, `meta charset`, `meta viewport`)
- Every `<img>` must have a meaningful `alt` attribute
- Use semantic tags (`header`, `nav`, `main`, `section`, `article`, `footer`) instead of generic `<div>` where appropriate
- No inline CSS (`style="..."`) — external CSS file only, linked via `<link>`
- Code must pass the W3C Validator (validator.w3.org) with 0 errors before submission
- **Submission is via GitHub only** — no ZIP files accepted (see the Submission Guide at the end of this document)

---

# LAB 1 (MEDIUM) — "Recipe Blog Page"

**Estimated time:** 120 minutes
**Skill level:** Students who have completed headings, paragraphs, lists, links, and images, and are now combining them into one complete page.
**Reference image:** `lab1_recipe_page.png`

## Learning Objectives
By the end of this lab, students will be able to:
- Structure a single HTML page using semantic HTML5 tags
- Use ordered, unordered, nested, and definition lists correctly in context
- Use all three types of hyperlinks (external, local/anchor, relative) in one page
- Submit a project to GitHub using basic Git commands

## Scenario
You are building a single-page recipe blog post for a fictional food blog. The page presents one recipe from introduction to final result, matching the layout shown in `lab1_recipe_page.png`.

## Requirements

### Part A — Page Structure (must use semantic tags)
| Section | Required content |
|---|---|
| `<header>` | Blog/recipe name (as `<h1>`), a `<nav>` with 3 local anchor links: "Ingredients", "Steps", "Notes" |
| `<main>` | Contains all sections below |
| `<section id="intro">` | A short 2–3 sentence introduction, one image of the finished dish (with `loading="lazy"`) |
| `<section id="ingredients">` | An **unordered list** of at least 8 ingredients |
| `<section id="steps">` | An **ordered list** of at least 6 cooking steps. At least 1 step must contain a **nested unordered list** (e.g., a step listing topping options) |
| `<section id="notes">` | A **definition list** (`<dl>`) with at least 3 cooking terms and their definitions |
| `<footer>` | Copyright line + one **external link** to a real recipe website, opening in a new tab (`target="_blank"`) |

### Part B — Hyperlink Requirements (must use all 3 types correctly)
- **External hyperlink**: at least 1, pointing to a real website, using `target="_blank"`
- **Local hyperlink (anchor)**: the 3 nav links from the header, each jumping to its matching `id`
- **Relative hyperlink**: a link at the bottom of the page to a second file `about.html` (a very simple "About the Author" page you also create, with just a heading and one paragraph, and a relative link back to `index.html`)

### Part C — Images
- At least 2 images total (1 main dish photo, 1 ingredient/step photo)
- All images must have descriptive `alt` text (not "image1" or "photo")
- All images must use `loading="lazy"`

### Part D — Data attribute (just introduce it, no JavaScript needed)
- Add a `data-difficulty="easy|medium|hard"` attribute to the `<section id="steps">` tag or to the page's `<body>` tag, reflecting how difficult you think the recipe is. This is only meant to demonstrate that you understand what `data-*` attributes are for (JavaScript will read attributes like this in a later course).

### Part E — Basic external CSS (`style.css`)
- Link the stylesheet with `<link rel="stylesheet" href="style.css">` in `<head>`
- Give `<header>` and `<footer>` a background color and white text
- Give the page a readable `font-family` and a comfortable `line-height`
- This is basic styling only — no positioning, no Flexbox/Grid (not covered yet)

## Deliverables Checklist
- [ ] `index.html` — main recipe page
- [ ] `about.html` — simple secondary page (for the relative link)
- [ ] `style.css` — external stylesheet
- [ ] At least 2 images used in the project
- [ ] 0 errors in W3C Validator for both HTML files
- [ ] Pushed to a public GitHub repository named `lab1-recipe-blog`
- [ ] Live and working on GitHub Pages

## Grading Rubric

| Criterion | Weight |
|---|---|
| Correct semantic HTML structure | 20% |
| All 3 hyperlink types implemented correctly | 20% |
| Lists used correctly (ordered, unordered, nested, definition) | 25% |
| Images with proper `alt` and `loading="lazy"`, `data-*` attribute present | 15% |
| Basic CSS linked and applied correctly (external file only) | 10% |
| GitHub submission (repo public, pushed correctly, Pages live) | 10% |

---

# LAB 2 (HARD) — "3-Page Local Travel Guide"

**Estimated time:** 120 minutes
**Skill level:** Students comfortable with single-page HTML who are ready to manage multiple linked pages and embedded media.
**Reference images:** `lab2_home_page.png`, `lab2_destinations_page.png`

## Learning Objectives
By the end of this lab, students will be able to:
- Build and correctly link a multi-page website (3 pages) using **relative links**
- Reuse a consistent `<header>`/`<nav>`/`<footer>` structure across pages
- Embed audio and/or video using native HTML tags
- Nest lists and definition lists to represent richer real-world content
- Manage a multi-file project through Git with a clean commit history

## Scenario
You are building a 3-page local travel guide website: **Home**, **Destinations**, and **Media**. Every page is a separate `.html` file, all sharing the same header, navigation, and footer — see `lab2_home_page.png` and `lab2_destinations_page.png` for the expected look.

## Requirements

### Part A — Site-wide structure (applies to all 3 pages)
- All 3 pages must share **the same** `<header>` with an `<h1>` and a `<nav>` linking to all 3 pages using **relative links**
- All 3 pages must share **the same** `<footer>`, including one external link
- All 3 pages must link to the **same** external `style.css` file
- Every page must have exactly **one** `<h1>`

### Part B — `index.html` (Home page)
- A short hero section: heading, 2–3 sentence introduction, and one large image (with `alt` and `loading="lazy"`)

### Part C — `destinations.html`
- At least 2 destinations, each inside its own `<article>` tag, each including:
  - A destination name (`<h3>`)
  - One image with descriptive `alt` and `loading="lazy"`
  - A short description paragraph
  - Either a **nested unordered list** ("Things to do") or a **definition list** ("Quick Facts") — use at least one of each across the two destinations
  - A `data-category="mountain|beach|city"` attribute on the `<article>` tag

### Part D — `media.html`
- Embed **one audio file** using `<audio controls>` with at least one `<source>` and fallback text
- Embed **one video file** using `<video controls>` with at least one `<source>` and fallback text
  - (You may use any short royalty-free clip you find, or a local placeholder file — the grading focus is correct HTML syntax, not the media content itself)
- A short paragraph describing what the audio/video shows

### Part E — Folder structure requirement
```
lab2-travel-guide/
├── index.html
├── destinations.html
├── media.html
├── style.css
└── media/
    ├── destination1.jpg
    ├── destination2.jpg
    ├── guide-audio.mp3
    └── guide-video.mp4
```
All references in HTML must correctly use the `media/` relative path.

## Deliverables Checklist
- [ ] 3 HTML pages, all sharing the same header/nav/footer structure
- [ ] Working relative navigation between all 3 pages
- [ ] At least 2 destinations using `<article>`, with nested/definition lists and `data-category`
- [ ] `media.html` with working `<audio>` and `<video>` embeds (with fallback text)
- [ ] Correct folder structure with a `media/` subfolder
- [ ] 0 errors in W3C Validator for all 3 HTML files
- [ ] At least **4 separate commits** on GitHub, each with a clear message (e.g., "Add home page", "Add destinations page", "Add media page", "Style all pages")
- [ ] Pushed to a public GitHub repository named `lab2-travel-guide`
- [ ] Live and working on GitHub Pages, tested by clicking through all navigation links on the live site

## Grading Rubric

| Criterion | Weight |
|---|---|
| Multi-page navigation works correctly (relative links) | 15% |
| Destinations content correctness (articles, lists, `data-*`) | 25% |
| Audio/video embedding correctness | 20% |
| Consistent header/footer/CSS across all pages | 15% |
| Folder structure and media paths correct | 10% |
| Git usage (commit history quality, not just 1 commit) | 10% |
| GitHub Pages live and fully working | 5% |

---

# LAB 3 (VERY HARD) — "4-Page Documentation Site for a Fictional App"

**Estimated time:** 120 minutes (this lab is intentionally tight — it rewards students who plan the page structure before coding)
**Skill level:** Students who have completed Labs 1 and 2, comfortable with multi-page linking and embedded media. This lab pushes into deeper information architecture and list nesting — still only HTML tags taught in Lecture 03 (no CSS layout tricks, no JavaScript).
**Reference images:** `lab3_home_sitemap.png`, `lab3_features_page.png`

## Learning Objectives
By the end of this lab, students will be able to:
- Plan and implement a small but realistic information architecture (4 pages with a shared navigation system)
- Build a nested "site map" list that links to every page and to sections within pages (combining relative links and anchor links)
- Use `<aside>` correctly for supplementary content, alongside `<header>`/`<nav>`/`<main>`/`<article>`/`<footer>`
- Nest lists three levels deep in at least one place
- Manage a larger multi-page project through Git with meaningful, incremental commits

## Scenario
You are building a small documentation website for a fictional product of your choice (an app, a board game, a piece of software). The site must have exactly **4 pages** and show that the semantic HTML5 tags and list types learned in Lecture 03 are enough to build a clear, well-organized site — see `lab3_home_sitemap.png` and `lab3_features_page.png` for the expected look.

## Requirements

### Part A — Site Architecture (exactly 4 pages)
| Page | Purpose |
|---|---|
| `index.html` | Landing page: product name, short description, and a **nested site map** — an unordered list linking to every other page **and** to specific sections within those pages (mixing relative links with anchor links, e.g. `href="features.html#tracking"`) |
| `getting-started.html` | Step-by-step onboarding guide as an **ordered list**, where at least one step contains a nested list that itself contains another nested list (3 levels deep total) |
| `features.html` | At least 2 features, each inside its own `<article>` (with an `id` so the site map can link to it), each with one image (`alt` + `loading="lazy"`), a short paragraph, and either a nested list or a definition list |
| `media-faq.html` | Embeds **one audio** and **one video** (`<audio controls>` / `<video controls>`, each with `<source>` and fallback text), plus a short FAQ section using at least 4 question/answer pairs written as a **definition list** (`<dt>` = question, `<dd>` = answer) |

### Part B — Shared layout across all 4 pages
- Same `<header>` with `<h1>` and a `<nav>` linking to all 4 pages (relative links)
- Every page's `<main>` content is paired with an `<aside>` containing 2–3 "Related Links" (external links, `target="_blank"`)
- Same `<footer>` on all pages
- Every page has exactly **one** `<h1>`, and headings do not skip levels (no jumping from `<h2>` straight to `<h4>`)

### Part C — `data-*` usage
- Add a `data-widget="related-links"` attribute to every `<aside>` tag
- Add a `data-category="..."` attribute to each `<article>` in `features.html`

### Part D — Self-check note (submit as a short `NOTES.md` file in the repo)
Before submitting, run the **W3C Validator** on all 4 pages and paste or screenshot the "0 Errors" result for each into `NOTES.md`. If you had errors and fixed them, briefly note what the issue was (1 sentence per issue) — this is good practice for catching your own mistakes.

## Deliverables Checklist
- [ ] Exactly 4 HTML pages with consistent shared header/nav/footer
- [ ] Home page site map correctly mixes relative links and anchor links
- [ ] At least one 3-level-deep nested list on `getting-started.html`
- [ ] `features.html` has 2+ articles with `id`s matching the site map's anchor links
- [ ] `media-faq.html` has working audio + video embeds and a 4+ item FAQ definition list
- [ ] `<aside>` used correctly on every page, with `data-widget` attribute
- [ ] Correct heading hierarchy on every page (no skipped levels)
- [ ] `NOTES.md` file with Validator results included in the repository
- [ ] 0 errors in W3C Validator across **all 4** pages
- [ ] At least **6 separate, meaningful commits** on GitHub showing incremental progress
- [ ] Pushed to a public GitHub repository named `lab3-docs-site`
- [ ] Live and fully working on GitHub Pages

## Grading Rubric

| Criterion | Weight |
|---|---|
| Site architecture & navigation across 4 pages | 15% |
| Site map correctness (mixed relative + anchor links) | 15% |
| List nesting depth and correctness (3 levels, FAQ `dl`) | 20% |
| `<aside>`/semantic structure and `data-*` usage | 15% |
| Audio/video embedding correctness | 10% |
| Self-check quality (`NOTES.md` completeness and honesty) | 10% |
| Git commit history (meaningful, incremental, not one giant commit) | 10% |
| GitHub Pages live and fully working | 5% |

### Bonus (optional, up to +5%)
- Add a 5th page (`troubleshooting.html`) with its own nested FAQ-style definition list, linked from the site map

---

# GITHUB SUBMISSION GUIDE (applies to all 3 labs)

Since submission is via GitHub for all three labs, follow this exact workflow for each lab.

### Step 1 — Create the repository
1. Log in to GitHub → click **New repository**
2. Repository name: use the exact name specified in each lab (`lab1-recipe-blog`, `lab2-travel-guide`, or `lab3-docs-site`)
3. Set visibility to **Public** (required for free GitHub Pages)
4. Do **not** initialize with a README (to avoid merge conflicts later)

### Step 2 — Initialize Git locally and push
```bash
git init
git add .
git commit -m "Initial commit: project structure"
git remote add origin https://github.com/<your-username>/<repo-name>.git
git branch -M main
git push -u origin main
```

### Step 3 — Commit incrementally as you work
Do **not** wait until the end to make a single commit. Commit after each meaningful milestone:
```bash
git add .
git commit -m "Add navigation and header across all pages"
git push
```
Labs 2 and 3 specifically grade commit history — a single "final submission" commit will lose points.

### Step 4 — Enable GitHub Pages
1. Go to your repository → **Settings** → **Pages**
2. Under "Build and deployment" → "Source", select **Deploy from a branch**
3. Branch: **main**, folder: **/ (root)** → **Save**
4. Wait 30–60 seconds, refresh the page — you will see: *"Your site is live at `https://<username>.github.io/<repo-name>/`"*

### Step 5 — Submit
Submit **two links** through the class LMS/form:
1. The GitHub repository URL
2. The live GitHub Pages URL

No ZIP files will be accepted for any of these three labs.

### Common issues and fixes
| Issue | Cause | Fix |
|---|---|---|
| GitHub Pages shows a 404 | `index.html` is not at the repository root, or is misnamed | Confirm `index.html` (lowercase) sits directly in the repo root, not inside a subfolder |
| Page loads but has no styling | `<link>` `href` path is wrong (e.g., an absolute local path was used) | Use relative paths only, e.g., `href="style.css"`, never `C:/Users/...` |
| `git push` keeps asking for a password and rejecting it | GitHub no longer accepts account passwords over the command line | Generate a Personal Access Token (GitHub → Settings → Developer settings → Personal access tokens) and use it in place of the password |
| Site not updating after `git push` | GitHub Pages needs time to rebuild | Wait 1–2 minutes and hard-refresh (`Ctrl+Shift+R`) |
| Audio/video doesn't play on GitHub Pages | Media file path is wrong, or file wasn't pushed (check `.gitignore`) | Confirm the file exists in the `media/` folder on GitHub itself, not just locally |
